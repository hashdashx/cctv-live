
# NVR Web v014g-ws (fix1)

- Modern browser: WebSocket H.264 (Annex-B) + WebCodecs (autoplay).
- LG NetCast: Legacy MP4 stabil, grid kompatibel.
- Status per kamera: `/api/status` di UI.
- FIX1: perbaikan regex `/^\/ws\/([^\/]+)$/` pada upgrade handler.
